﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");


class Food
{
    public string Name;
    public int Calories;
    public bool IsSpicy; 
    public bool IsSweet; 

    public Food(string name, int cal, bool is_spicy, bool is_sweet)
    {
        Name = name;
        Calories = cal;
        IsSpicy = is_spicy;
        IsSweet = is_sweet;
    }
}

class Buffet
{
    public List<Food> Menu;
    Random rand = new Random();
    //constructor
    public Buffet()
    {
        Menu = new List<Food>()
        {
            new Food("Burger", 1000, true, false),
            new Food("Burger", 1000, true, false),
            new Food("Burger", 1000, true, false),
            new Food("Chiken Rice", 1300, true, false),
            new Food("Roasted Turkey", 2400, true, false),
            new Food("Cheese Cake", 2400, false, true),
            new Food("Baklawa", 400, false, true)
        };
    }
    
    public Food Serve()
    {
        Food served_food = Menu [rand.Next(0,6)];
        return served_food;
    }
}

class Ninja
{
    private int calorieIntake;
    public List<Food> FoodHistory;
    
    // add a constructor
    public  Ninja(int calintake, Food food)
    {
        calorieIntake = calintake;
        FoodHistory.Add (food); 
    }


    // add a public "getter" property called "IsFull"
    public bool IsFull ()
    {
        if (calorieIntake > 1200) return true;
        else return false;
    }
    // build out the Eat method
    public void Eat(Food item)
    {
        if(IsFull()) 
        {
            System.Console.WriteLine("Ninja is full");
        }
        else 
        {
            calorieIntake += item.Calories;
            FoodHistory.Add (item);
            System.Console.WriteLine(" Food eaten " + item.Name + " " + item.Calories+" cal");
            if(item.IsSweet) System.Console.WriteLine("Food is Sweet");
            if(item.IsSpicy) System.Console.WriteLine("Food is Spicy");
        }
        
    }
}


﻿Buffet buffet = new();

Ninja ninjaOne = new Ninja();

ninjaOne.Eat(buffet.Serve());